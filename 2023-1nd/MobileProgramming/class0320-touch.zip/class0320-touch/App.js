import { Text, View, StyleSheet } from 'react-native';
import Header from './components/Header'
export default function App(){

  return (
    <View>
      <Header>
        name="Park"
      </Header>
    </View>
  )
}