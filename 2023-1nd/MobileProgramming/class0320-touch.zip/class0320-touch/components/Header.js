import {View,Text} from 'react-native'

export default Header=(props)=>(
  <View>
    <Text>
      {props.name}
      테스트
    </Text>
  </View>
)