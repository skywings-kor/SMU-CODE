import {View, Button,StyleSheet} from 'react-native'

const Minus=(props)=>{
  return(
    <View>
      <Button
        color='red'
        title="-"
        onPress={()=>props.minus()}
      />

    </View>
  )
}

export default Minus
