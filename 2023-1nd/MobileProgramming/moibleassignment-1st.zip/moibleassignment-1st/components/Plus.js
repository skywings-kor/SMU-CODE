import {View, Button} from 'react-native'

const Plus=(props)=>{

  return(
    <View>
      <Button
        color='green'
        title="+"
        onPress={()=>props.add()}
      />

    </View>
  )
}

export default Plus