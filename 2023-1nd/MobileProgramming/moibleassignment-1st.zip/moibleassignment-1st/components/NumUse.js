import {Text,TouchableOpacity,StyleSheet,View} from 'react-native'
const NumUse=(props)=>(
    <TouchableOpacity
      onPress={() => props.reset()}
    >
      <Text style={styles.mainText}> {props.sendNumber}</Text>
    </TouchableOpacity>
    
)

export default NumUse



const styles=StyleSheet.create({
  mainText:{
    fontSize:50,
    fontWeight:'bold',
    padding:10
  },
});