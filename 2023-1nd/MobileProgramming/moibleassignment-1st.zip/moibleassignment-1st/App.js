import {StyleSheet, Text, View} from 'react-native'
import Plus from './components/Plus'
import Minus from './components/Minus'
import NumUse from './components/NumUse'

import {useState} from 'react'

export default function App() {

  const [number,setNumber]=useState(1);

  const onAddNum=()=>{ 
    setNumber(number+1)
  }

  const onMinusNum=()=>{
    setNumber(number-1)
  }

  const onNumReset=()=>{
    setNumber(number-number)
  }
  return(
    <View style={styles.mainView}>
      <View>
        <Plus add={onAddNum}/>
        <NumUse reset={onNumReset} sendNumber={number}/>

        <Minus minus={onMinusNum}/>
      </View>

    </View>

  )
}

const styles=StyleSheet.create({
  mainView:{
    flex:1,
    backgroundColor:'yellow',
    height:"100%",
    alignItems:'center',
    justifyContent:'center'
  },
});