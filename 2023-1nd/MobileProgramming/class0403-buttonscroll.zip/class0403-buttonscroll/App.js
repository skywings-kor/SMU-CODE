import {View,TextInput, Text, StyleSheet, Button,ScrollView} from 'react-native'
import {useState} from 'react'

/**export를 가져와야함 */
export default function App(){
  const [myTextInput,setMyTextInput] = useState("")
  const [alphabet,setAlphabet] = useState([
    'a','b','c','d'
  ])

  const onChangeInput=(event) =>{
    setMyTextInput(event)
  }

  const onAddTextInput=()=>{

    {/** ... 이거는 값 복사 */}
    setAlphabet([...alphabet,myTextInput])

    {/**이 밑에것을 넣으면 한 번 버튼을 누르면 빈칸으로 만들어줌 */}
    setMyTextInput("")
  }


  return(
    <View>
      <TextInput
      style={styles.input}
        value={myTextInput}
        onChangeText={onChangeInput}
        multiline={true}
      />

      <Button
        title="Add Text Input"
        onPress={onAddTextInput}
      />

      {/**ScrollView로 감싸줘서 스크롤 가능하게 하기 */}
      <ScrollView>
        {
          //맵 관련해서 조금 더 여쭤보기-교수님께....
          alphabet.map((item,idx)=>{
            return(
              <Text
                style={styles.mainText}>
                {item}
              </Text>
            )
          })
        }

      </ScrollView>


    </View>
  )

}

/**시험확률 높아요요 */
const styles=StyleSheet.create({
  input:{
    width:"100%",
    backgroundColor:"grey",
    fontSize:45,
    padding:10,
    color:'red'
  },

  mainText:{
    fontSize:20,
    color:'red',
    padding:10,
    margin:10,
    backgroundColor:'pink'
  }
})