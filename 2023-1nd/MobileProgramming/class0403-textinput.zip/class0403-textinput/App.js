import {View, ScrollView } from 'react-native';
import {useState} from 'react'

import Header from './components/Header'
import Generator from './components/Generator'
import Minus from './components/Minus'
import Numlist from './components/numlist'
import Input from './components/Input'
export default function App() {
    const[appName,setAppName]=useState("FirstAPP")
    const [random,setRandom]= useState([
      3,6
    ])

    const onAddRandomNum=()=>{
      const newNum=Math.floor(Math.random()*100)
      
      setRandom([...random,newNum])
    }

    const onNumDelete=(position)=>{
      const newArray= random.filter((num,index)=>{
        return position !=index
      })
      setRandom(newArray)
    }


    
  return (
    <View>
      <Input>
      
      </Input>
      
      <Header name={appName}/>
      
      <Generator add = {onAddRandomNum}/>
      <ScrollView style={{width:'100%'}}
        bounce={true}
      >
        <Numlist num={random} delete = {onNumDelete}/>
      </ScrollView>
    </View>
  );
}

