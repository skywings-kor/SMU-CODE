import {View, TextInput, Text} from 'react-native'
import {useState} from 'react'

const Input = ()=>{
  
  const [myTextInput,setMyTextInput]=useState ("이 문장을 바꿔보시지!")

  const onChangeInput=(event)=>{
    {/* 여기는  */}
    setMyTextInput(event)
  }
  return(
    //최상위 컴포넌트 꼭 선언(안하면 오류가 뜸)
    <View>
      <TextInput
        value={myTextInput}

        //이 useState를 선언 함으로써 기존 myTextInput만 있을 떄 문장을 바뀌도록 하기
        onChangeText={onChangeInput}
        multiline={true}

        /* 이것은 글자 길이 제한  */
        maxLength={20}

        /** 이것은 변경 안되게 하는거 */
        /** 어느 순간 editable이 false가 되게하여 뭔가 응용할 만한 것 떠올리기-만들기 */
        editable={true}
      />
      
      {/*이 myTextInput에 변경된 내용들이 바로바로 같이 적용됨*/}
      <Text>
      
        {myTextInput}
      </Text>

    </View>
  )
}

export default Input