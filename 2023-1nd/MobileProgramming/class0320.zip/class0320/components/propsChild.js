import {View, Text} from 'react-native'

//const props=... 이건 객체 형태
//changeState 넘겨준 값 

export const PropsChild=(props) =>{

  return(
    <View>
      {props.inputText()}
      <Text onPress={props.changeState}>Button</Text>
    </View>
  );
}

export default PropsChild