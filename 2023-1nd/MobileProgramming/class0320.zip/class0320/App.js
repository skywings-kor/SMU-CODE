import { Text, View, StyleSheet } from 'react-native';
import {useState} from 'react'
import PropsChild from './components/propsChild'

export default function App()
{
  const [sample,setSample]=useState(false)
  const changeState=() =>{
    if(sample)
    {
      setSample(false)
    }
    else
    {
      setSample(true)
    }
  }

  const inputText=() =>{
    if(sample){
      return <Text> 진실</Text>
    }
    else{
      return <Text> 거짓</Text>
    }
  }
  /*이렇게 하면 코드 안에는 바꼈는데 화면 코드 관련된거 안바껴서 적용이 안된 것*/
  return(
    <View>
      <PropsChild 
        changeState={changeState}
        inputText={inputText}
      />

      <PropsChild 
        changeState={changeState}
        inputText={inputText}
      > </PropsChild> 

      
    </View>
  );
}