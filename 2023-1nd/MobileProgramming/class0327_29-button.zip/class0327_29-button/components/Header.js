import {View,Text} from 'react-native'

export default Header=(props)=>(
  <View>
    <Text>
      
    </Text>
  </View>
)