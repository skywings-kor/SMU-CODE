import { Text, View, StyleSheet } from 'react-native';

export default function App() {
  return (
    <View style={{
      //backgroundColor:"red",
      flex:1,
      //height:"100%",
    }}>
    <View style={styles.subView1}>
      <Text> subView 1</Text>``
    </View>
    <View style={styles.subView2}>
      <Text> subView 2</Text>
    </View>
    <View>
      <Text> subView 3</Text>
    </View>

    <Text> This is Text component. </Text>
    </View>
  );
}

//플렉스 부분 시험에 나옵니다!!
const styles = StyleSheet.create({
  subView1:{
    flex:1,
    backgroundColor:"green"
  },
  subView2:{
    flex:3,
    backgroundColor:"yellow"
  },
});
