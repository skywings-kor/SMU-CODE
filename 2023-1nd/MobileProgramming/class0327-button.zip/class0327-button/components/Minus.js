import {View,Button} from 'react-native'

const Minus=(props)=>{
  return(
    <View>
      <Button
        title="-"
        onPress={()=>props.add()}
      />
    </View>
  )
}

export default Minus