import {Text,TouchableOpacity}from 'react-native'

const Numlist=(props)=>(
  props.num.map((item,idx)=>(
    <TouchableOpacity
      key={idx}
      onPress={() => props.delete(idx)}
    >
      <Text>{item}</Text>
    </TouchableOpacity>
    )
  )
)

export default Numlist