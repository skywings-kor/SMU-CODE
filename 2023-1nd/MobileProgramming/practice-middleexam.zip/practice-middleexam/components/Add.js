import {Button,View,StyleSheet,Text,TextInput} from 'react-native'
import {useState} from 'react'

const Add=(props)=>(
  <Button
    title="Add on Text"
    onPress={()=>props.sn()}
  />
)

export default Add