import {Button,View,StyleSheet,Text,TextInput} from 'react-native'
import {useState} from 'react'

const Numlist=(props)=>(
  props.sss.map((item,idx)=>(
    <View style={styles.textView}>
      {item}
    </View>
  ))
  
)

export default Numlist

const styles=StyleSheet.create({
  textView:{
    fontSize:20,
    backgroundColor:'pink',
    alignItems:'center',
    justifyContent:'center',
    margin:5,
    padding:10
  }
})