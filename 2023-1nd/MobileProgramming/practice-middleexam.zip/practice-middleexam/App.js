import {View,Text,Button,StyleSheet,TextInput} from 'react-native'
import {useState} from 'react'
import Add from './components/Add'
import Numlist from './components/Numlist'

export default function App(){
  const [number,setNumber]=useState()
  const [storage,setStorage]=useState(['a','b','c','d'])
  
  const onChange=(event)=>{
    setNumber(event)
  }
  
  const addNum=()=>{
    setStorage([...storage,number])
    setNumber("")
  }
  return(

    <View>
      <TextInput
        style={styles.inputView}
        value={number}
        editable={true}
        multiline={true}
        maxLength={20}
        onChangeText={onChange}
      />
      <Add sn={addNum}/>
      <Numlist sss={storage}/>
      

    </View>
  )
}

const styles=StyleSheet.create({

  inputView:{
    backgroundColor:"grey",
    height:80,
    fontSize:40,
    color:'blue'
  }
})