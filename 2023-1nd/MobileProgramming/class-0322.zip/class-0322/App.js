import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';

// const header = )_=> (  ) 이런식으로 안에 무언가 채우기만 하면 return () 이거 안에 작성할 필요가 없음.. (5th-5p)
export default function App() {
  return (
    <View/>

  );
}

